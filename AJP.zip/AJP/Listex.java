import java.awt.*;
class Listex extends Frame
{
  Listex()
   {
   List l1=new List();
    l1.add("Summer");
    l1.add("Winter");
    l1.add("Rainy");
    add(l1);
    
    setSize(400,400);
    setVisible(true);
    setLayout(null);
     }
 public static void main(String s[])
     {
      Listex l1=new Listex();
     }
}
  