import java.awt.*;
class CheckboxEx extends Frame
   {
     CheckboxEx()
      {
       Checkbox c1=new Checkbox("C");
       Checkbox c2=new Checkbox("C++");
       Checkbox c3=new Checkbox("java",true,null);
       
     
      add(c1);
      add(c2);
      add(c3);
     
      List l1=new List();
      l1.add("Shubham");
      l1.add("Alim");
      l1.add("Suyash");
      l1.add("Samudre");
      l1.add("Shubham");
      l1.add("Alim");
      l1.add("Suyash");
      l1.add("Samudre");
      add(l1);
      

      setSize(400,400);
      setVisible(true);
      setLayout(new FlowLayout());
      }
     public static void main(String s[])
      {
       CheckboxEx b1=new CheckboxEx();
      }
}