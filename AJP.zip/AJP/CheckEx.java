import java.awt.*;
class CheckEx extends Frame
   {
     CheckEx()
      {
       Checkbox c1=new Checkbox("C");
       Checkbox c2=new Checkbox("C++");
       Checkbox c3=new Checkbox("java",true,null);
       
     
      add(c1);
      add(c2);
      add(c3);
     
      List l1=new List();
      l1.add("Shubham");
      l1.add("Alim");
      l1.add("Suyash");
      l1.add("Samudre");
      add(l1);
      

      setSize(400,400);
      setVisible(true);
      setLayout(new GridLayout(4,1));
      }
     public static void main(String s[])
      {
       CheckEx b1=new CheckEx();
      }
}