// java Program to create a slider with min and 
// max value and major and minor ticks painted. 
import javax.swing.event.*; 
import java.awt.*; 
import javax.swing.*; 
class solve1 extends JFrame implements ChangeListener { 

	static JFrame f; 
	static JSlider b; 
	static JLabel l; 
	public static void main(String[] args) 
	{ 
		f = new JFrame("frame"); 
		solve1 s = new solve1(); 
		l = new JLabel(); 
		JPanel p = new JPanel(); 
		b = new JSlider(0, 200, 120); 
		b.setPaintTrack(true); 
		b.setPaintTicks(true); 
		b.setPaintLabels(true); 
		b.setMajorTickSpacing(50); 
		b.setMinorTickSpacing(5); 

		// setChangeListener 
		b.addChangeListener(s); 
		p.add(b); 
		p.add(l); 
		f.add(p); 
		l.setText("value of Slider is =" + b.getValue()); 
		f.setSize(300, 300); 
		f.show(); 
	} 
	public void stateChanged(ChangeEvent e) 
	{ 
		l.setText("value of Slider is =" + b.getValue()); 
	} 
} 
