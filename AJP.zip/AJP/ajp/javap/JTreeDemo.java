/*<applet code="JTreeDemo" height=200 width=300>
</applet>*/

import java.awt.*;    
import java.awt.event.*;    
import javax.swing.*; 
import java.util.* ;
import javax.swing.tree.* ;   		             

public class JTreeDemo extends JApplet   
{
  JTree  jt;     
  JTextField jtf;
   
  public void start()   
  {
    setVisible(true);
  setSize(400,400);
    Container c = getContentPane();
    c.setLayout(new BorderLayout());
  	                                      //  this is the root node and top in the hierarchy
    DefaultMutableTreeNode rootnode = new DefaultMutableTreeNode("Sports");
    DefaultMutableTreeNode anode = new DefaultMutableTreeNode("Air games");
    rootnode.add(anode);     		      // becomes a file to rootnode
                                              // create ogames node add to the rootnode (becomes child node of rootnode)

    DefaultMutableTreeNode ogames = new DefaultMutableTreeNode("OutDoor Games");
    DefaultMutableTreeNode bnode = new DefaultMutableTreeNode("Basket ball");
    DefaultMutableTreeNode vnode = new DefaultMutableTreeNode("Volley ball");
    ogames.add(bnode);  		      // becomes file to ogames
    ogames.add(vnode);   		      // becomes file to ogames
    rootnode.add(ogames); 		      // add ogames to rootnode

                                              // create igames node add to the rootnode(becomes child node of rootnode)
   DefaultMutableTreeNode igames = new DefaultMutableTreeNode("Indoor Games");
  
   DefaultMutableTreeNode cnode = new DefaultMutableTreeNode("Carroms");
   DefaultMutableTreeNode tnode = new DefaultMutableTreeNode("Table Tennis");
   igames.add(cnode);		              // becomes file to igames
   igames.add(tnode);		              // becomes file to igames
   rootnode.add(igames); 		      // add igames to rootnode
   		                              // this node becomes child node to igames

   DefaultMutableTreeNode snode = new DefaultMutableTreeNode("Skill Games");
   DefaultMutableTreeNode shnode = new DefaultMutableTreeNode("Shooting");
   DefaultMutableTreeNode banode = new DefaultMutableTreeNode("Bar Dancing");
   snode.add(banode);  		              // becomes a file to snode
   igames.add(snode); 		              // becomes a file to snode
   snode.add(shnode); 		              // snode is the child node to igames

   jt = new JTree(rootnode); 		      // add root node to the JTree
   int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
   int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
   JScrollPane jsp = new JScrollPane(jt , v , h);

   c.add(jsp, "Center");   		      // add scroll pane to the container
   jtf = new JTextField(20);
   c.add( jtf, "South");
  //add(c);

   jt.addMouseListener(new MouseAdapter()   
   {
       public void mouseClicked(MouseEvent e)   
       {
         display(e);
    }  } ) ;
  }
  public void display(MouseEvent e)   
  {
    TreePath tp = jt.getPathForLocation(e.getX(), e.getY());
    if( tp  !=  null)
    System.out.println(tp);      
//jtf.setText(tp.toString());
    else
      //jtf.setText("");
     System.out.println(" ");
  }
}