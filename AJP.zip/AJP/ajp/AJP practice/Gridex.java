import java.awt.*;
public class Gridex 
{
   Frame f=new Frame();
   
   Button b1,b2,b3,b4,b5;
   Gridex()
   {
     f.setSize(400,400);
     f.setVisible(true);
     b1=new Button("button one");
     b2=new Button("button two");
     b3=new Button("button three");
     b4=new Button("button four");
     b5=new Button("button five");
     f.setLayout(new GridBagLayout());
     GridBagConstraints gc =new GridBagConstraints();
     
    add(b1,gc,0,0,1,1,12,0);
    add(b2,gc,1,0,1,1,0,0);
    add(b3,gc,0,1,1,1,5,20);
    add(b4,gc,1,1,1,1,0,20);
    add(b5,gc,0,2,2,1,90,15);
  }
    void add(Component comp,GridBagConstraints gc,int x,int y,int w,int h,int wx,int wy)
     {   
         gc.gridx = x;
         gc.gridy = y;
         gc.gridwidth = w;
         gc.gridheight= h;
         gc.ipadx = wx;
         gc.ipady = wy;
         f.add(comp,gc);
     }

public static void main(String args[])
       {
           
           Gridex ge=new Gridex();
      }
}
