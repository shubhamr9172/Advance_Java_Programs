import java.awt.*;
import javax.swing.*;
/*<Applet code="MainClass1" Height=300 width=300>
</Applet>*/
public class MainClass1 extends JApplet {
  public void init()
{

 
    Container cp=getContentPane();
    
    ImageIcon pic = new ImageIcon("lion.gif");
    JLabel l1 = new JLabel("The Lion King",pic,JLabel.CENTER);
    cp.add(l1);
    
  }
}