   
import javax.swing.*;

public class LabelExample extends JFrame {
 

  public LabelExample() {
    this.setTitle("Picture Application");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    ImageIcon pic = new ImageIcon("lion.gif");
    JLabel l1=new JLabel("Lion",pic,JLabel.LEADING);
    this.add(l1);
    this.setVisible(true);
    this.setSize(400,400);
  }
 public static void main(String[] args) 
{
    new LabelExample();
  }
}