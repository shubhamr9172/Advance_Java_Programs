
import java.awt.*;
public class Grid extends Frame
{
	 
      //Panel p=new Panel();
 Grid()
      
 {
      setSize(400,400);
      setVisible(true);
      GridLayout g=new GridLayout(5,5);
      setLayout(g);
      for(int i=0;i<25;i++)
       {
        Panel b1=new Panel();
        add(b1);
        b1.setBackground(Randomcolor());
        }
 }
      public Color Randomcolor()
       {
          int r=(int)(Math.random()*256);
          int g=(int)(Math.random()*256);
          int b=(int)(Math.random()*256);
          return(new Color(r,g,b));
       }
 public static void main(String s[])
  {
   new Grid();
  }
}
       
	             

	            