import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Jcheck extends JFrame implements ItemListener
{
  JCheckBox cb1,cb2;
  ImageIcon ic1,ic2;
  TextField tf;
Jcheck()
{
  ic1=new ImageIcon("harmit.jpg");
  ic2=new ImageIcon("spider.jpg");
  cb1=new JCheckBox("gmail",ic1);
  cb1.setSize(25,25);
  cb2=new JCheckBox("rediff",ic2);  
  cb2.setSize(25,25);
 tf=new TextField(15);
  add(cb1);
  add(cb2);
  add(tf);
  setLayout(new FlowLayout());
  setSize(400,400);
  setVisible(true);
  cb1.addItemListener(this);
  cb2.addItemListener(this);
  //cb1.setActionCommand("harry");
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
public void itemStateChanged(ItemEvent ae)
{
 cb1.setRolloverIcon(ic2);
  JCheckBox str=(JCheckBox)ae.getItem();
  tf.setText(str.getText());
}
public static void main(String a[])
 {
   new Jcheck();
}
}

 