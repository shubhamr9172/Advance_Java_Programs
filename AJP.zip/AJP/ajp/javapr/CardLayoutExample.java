import java.awt.*;  
import java.awt.event.*;  
  
//import javax.swing.*;  
  
public class CardLayoutExample extends Frame implements ActionListener{  
CardLayout card;  
Button b1,b2,b3;  
//Container c;  
    CardLayoutExample(){  
          
       
        card=new CardLayout(40,30);  
//create CardLayout object with 40 hor space and 30 ver space  
        setLayout(card);  
         
        b1=new Button("Apple");  
        b2=new Button("Boy");  
        b3=new Button("Cat");  
        b1.addActionListener(this);  
        b2.addActionListener(this);  
        b3.addActionListener(this);  
              
        add(b1,"card1");
add(b2,"card2");
add(b3,"card3");  
          setSize(400,400);  
       setVisible(true);                   
    }  
    public void actionPerformed(ActionEvent e) {  
    card.next(this);  
    }  
  
    public static void main(String[] args) {  
        new CardLayoutExample();  
      
       //cl.setDefaultCloseOperation(EXIT_ON_CLOSE);  
    }  
}  