package swing;
import java.awt.*;
import java.net.URL;

import javax.swing.*;
/*<applet code=Jlabel1.class width=200 height=200>
 * </applet>
 */
public class Jlabel1 extends JApplet
{
	public void init()
	{
		Container cp=getContentPane();
		
		ImageIcon i=new ImageIcon("Koala.jpeg");
		JButton b=new JButton(i);
		cp.add(b);
	}

}
