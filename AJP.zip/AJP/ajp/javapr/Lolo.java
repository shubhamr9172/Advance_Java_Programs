import java.awt.*;
import javax.swing.*;

/*<APPLET CODE = "Lolo" WIDTH = 400 HEIGHT = 300>
	</APPLET>*/
public class Lolo extends JApplet
{
   
public void init()
  {
    //Container cp=getContentPane();
    ImageIcon ic=new ImageIcon("harry.jpg");
    setLayout(new FlowLayout());
    JLabel l1=new JLabel("hello",ic,JLabel.CENTER);
    add(l1);
   
  }
}
    

