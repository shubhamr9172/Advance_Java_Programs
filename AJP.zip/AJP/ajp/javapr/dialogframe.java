//working.......
//Lecture 12
//add menuitem ka demo...
//add checkbox ka demo....
import java.awt.*;
import java.awt.event.*;

//main frame
public class dialogframe
{
   public static void main(String ar[])
{

   Frame f=new Frame("dialog example");
   FileDialog fd=new FileDialog(f,"file Dialog box");
   fd.setVisible(true);
   f.setSize(300,300);
   f.setVisible(true);
  

 
}
}
	
