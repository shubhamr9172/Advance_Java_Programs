import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Abbutton extends JFrame implements ActionListener
{
  JButton jb1;
  ImageIcon ic1,ic2;
  TextField tf;
Abbutton()
{
  ic1=new ImageIcon("harmit.jpg");
  ic2=new ImageIcon("spider.jpg");
  jb1=new JButton(ic1);
tf=new TextField(15);
  add(jb1);
  add(tf);
  setLayout(new FlowLayout());
  setSize(400,400);
  setVisible(true);
  jb1.addActionListener(this);
  jb1.setActionCommand("spider");
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
public void actionPerformed(ActionEvent ae)
{
  jb1.setPressedIcon(ic2);
  tf.setText(ae.getActionCommand());
}
public static void main(String a[])
 {
   new Abbutton();
}
}

 