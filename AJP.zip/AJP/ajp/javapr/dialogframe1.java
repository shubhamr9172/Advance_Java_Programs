//working.......
//Lecture 12
//add menuitem ka demo...
//add checkbox ka demo....
import java.awt.*;
import java.awt.event.*;

//main frame
public class dialogframe1  implements ActionListener
{
	TextField tf = new TextField(20);
	Button b,ok,cancel;         // = new Button("Show");
	Dialog dlg;
	String str;
	Frame f=new Frame("show");	
	
	dialogframe1()
	{
		b= new Button("Show");
                                ok=new Button("ok");
                                cancel=new Button("cancel");
		dlg= new Dialog(f,"d",true);
		f.setLayout(new FlowLayout());
		f.setTitle("TestFrame");
		f.add(tf);
		f.add(b);
                                dlg.add(ok);
                                dlg.add(cancel);
		f.setSize(200,200);
		f.setVisible(true);
                                dlg.setLayout(new FlowLayout());
		b.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == b)
		{		  
			dlg.setVisible(true);
		}
                               
	}
	public static void main(String[] args)
	{
		dialogframe1 f1 = new dialogframe1();
	}
}



	
