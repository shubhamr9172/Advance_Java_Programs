import java.awt.*;
import java.awt.event.*;
public class frameex extends Frame 
{
 public void paint(Graphics g)
	{
		g.setColor(Color.red);
		Font f1 = new Font("Times New Roman",Font.BOLD,20);
		g.setFont(f1);
		g.drawString("Hello world",100,100);
	}
     
 public static void main(String args[])
{
   Frame f=new frameex( );
   f.setSize(300,200);
   f.setTitle("This is Frame");
   f.setVisible(true);
f.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent e)
{
       System.exit(0);
}
});
   
  }
}