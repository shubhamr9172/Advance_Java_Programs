import java.awt.*;
import javax.swing.*;
/*<Applet code="MainClass1" Height=300 width=300>
</Applet>*/
public class MainClass1 extends JApplet {
  public void init()
{

 
    Container cp=getContentPane();
    
    ImageIcon pic = new ImageIcon("lion.gif");
    JTextField t1 = new JTextField("The Lion King",15);
    cp.add(t1);
    
  }
}