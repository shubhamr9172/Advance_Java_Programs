import java.awt.*;
//import java.awt.event.*;
public class Gridex extends Frame 
{
  int n=1;
  Color c;
  Button p;
  int r=0,g=0,b=0;
  Gridex()
    {
       setLayout(new GridLayout(5,5));
        //setFont(new Font("sansSerif",Font.BOLD,24));
         setSize(400,400);
         setVisible(true);
         //c=new Color(r,g,b);
       
        for(int i=0;i<25;i++)
         {  
               p=new Button();
                c=new Color(Color.Blue);
               add(p);
                 // r+=50;
                  //g+=50;
                  //b+=50;
               p.setBackground(c);
               
               
          }
}
    
 public static void main(String args[])
{
    new Gridex();  
}   
}