import java.awt.*;
class practical4 extends Frame
{
   practical4()
    {
     Label l1=new Label("Name :");
     Label l2=new Label("Comments :");
     TextField f1=new TextField();
     TextArea a1=new TextArea();
     Button b1=new Button("Submit");
    

      add(l1);
      add(f1);
      add(l2);
      add(a1);
      add(b1);
   
      setSize(400,400);
      setVisible(true);
      setLayout(new FlowLayout());
      
    }
public static void main(String s[])
   {
    practical4 p1=new practical4();
  }
}
      