import java.awt.*;
import java.awt.event.*;
public class AdapterEx {
 
Frame F;
AdapterEx(){
    F=new Frame("Window Adapter ");
    F.addWindowListener(new WindowAdapter(){
    public void windowClosing(WindowEvent e){
      F.dispose();
     }
    });
F.setSize(400,500);
F.setVisible(true);
}
public static void main(String s[])
{
new AdapterEx();
}
}