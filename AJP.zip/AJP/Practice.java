import java.awt.*;
class Practice extends Frame
{
   Practice()
   {
     Label l1=new Label("Name :");
     Label l2=new Label("Address :");
     Label l3=new Label("Phone :");
 
     TextField f1=new TextField();
     TextField f2=new TextField();
     TextField f3=new TextField();
     
     add(l1);
     add(f1); 
     add(l2);
     add(f2);
     add(l3);
     add(f3);
    


     f1.setSize(200,100);
     f2.setSize(200,100);
     f3.setSize(200,100);
     setSize(500,600);
     setVisible(true);
     setLayout(new GridLayout(3,2));
   }
 public static void main(String s[])
   {
   new Practice();
   }
}