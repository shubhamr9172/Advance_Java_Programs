import java.awt.*;
import java.awt.event.*;
class ScrollbarEX implements AdjustmentListener
{
Scrollbar sb=new Scrollbar(Scrollbar.HORIZONTAL);
Label l;
  

ScrollbarEX()
    {
     Frame f=new Frame("Scrollbar");
      l=new Label("hello");
      l.setAlignment(Label.CENTER);
      l.setSize(400,100);
      sb.setBounds(100,100,500,100);
      f.add(sb);
      f.add(l);
 

      f.setSize(500,400);
      f.setVisible(true);
      f.setLayout(null);

      sb.addAdjustmentListener(this);
 }

public void adjustmentValueChanged(AdjustmentEvent em)
   {
    l.setText("Horizontal Scrollbar"+sb.getValue());
  }
public static void main(String s[])
   {
     new ScrollbarEX();
  }
}
   