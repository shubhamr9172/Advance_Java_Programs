import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="MouseDemo4" width=300 height=200></applet>*/
public class MouseDemo4 extends Applet ,MouseMotionAdapter
{
Label l;
public void init()
{
 setLayout(null);
  l=new Label("Hello Mouse");
  l.setBounds(50,150,200,100);
 add(l);
 addMouseMotionListener(this);
}
public void mouseMoved(MouseEvent e)
{
setBackground(Color.red);

}
public void mouseDragged(MouseEvent e)
{
 setBackground(Color.black);
}
}
}