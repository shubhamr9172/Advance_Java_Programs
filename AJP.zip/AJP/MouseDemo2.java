import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="MouseDemo2" width=300 height=200></applet>*/
public class MouseDemo2 extends Applet implements MouseListener
{
Label l;
public void init()
{
 setLayout(null);
  l=new Label("Hello Mouse");
  l.setBounds(50,150,200,100);
 add(l);
 addMouseListener(this);
}
public void mousePressed(MouseEvent e)
{
setBackground(Color.red);

}
public void mouseReleased(MouseEvent e)
{
 
}
public void mouseEntered(MouseEvent e)
{
 
}
public void mouseExited(MouseEvent e)
{
 l.setText("Mouse Exited");
}
public void mouseClicked(MouseEvent e)
{
 l.setText("Mouse Clicked #of Clicks:"+e.getClickCount());
}
}