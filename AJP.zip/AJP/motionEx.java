import java.awt.*;
import java.awt.event.*;
 public class motionEx extends Frame implements MouseMotionListener
{
    motionEx()
    {
   addMouseMotionListener(this);
   setSize(400,500);
   setLayout(null);
   setVisible(true);
   }
public void mouseDragged(MouseEvent me)
 {
Graphics g=getGraphics();
g.setColor(Color.blue);
g.fillOval(me.getX(),me.getY(),20,20);
}
public void mouseMoved(MouseEvent me){

Graphics g=getGraphics();
g.setColor(Color.red);
g.drawLine(me.getX(),me.getY(),50,100);
}
public static void main(String s[])
 {
  new motionEx();
}
}