import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class JprogEx extends JFrame implements ActionListener
{
JProgressBar jb;
JButton b;
int i=0;
      JprogEx()
     {
      b=new JButton("ok");
      jb=new JProgressBar(0,100);
      jb.setValue(0);
       jb.setStringPainted(true);
     add(jb);
     add(b);
     b.addActionListener(this);
     setVisible(true);
     setSize(400,400);
     setLayout(new FlowLayout());
     }

public void actionPerformed(ActionEvent ae)
{
     while(i<=100)
   {
     jb.setValue(i);
     i=i+1;
 try{Thread.sleep(150);}catch(Exception e){}
   }
}
public static void main(String s[])
{
JprogEx b=new JprogEx();
}
}