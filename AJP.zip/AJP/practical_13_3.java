import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class practical_13_3 extends Applet
 {
   public void init()
   {
    addMouseMotionListener(new Demo1());
   }
 class Demo1 extends MouseMotionAdapter
  {
    public void mouseDragged(MouseEvent e)
      {
        showStatus("mouse dragged");
      }
   }
}
/*<applet code="practical_13_3" width=300 height=400></applet>*/