import java.awt.*;
class AJP1 extends Frame
{
   AJP1()
    {
    Label l1=new Label("Hii Everyone");
    
    List t1=new List();
    t1.add("java");
    t1.add("CSS");
    t1.add("OS");
t1.setBounds()
l1.setBounds(10,20,50,30);
    add(l1);
    setSize(400,500);
    setVisible(true);


     }
public static void main(String s[])
 {
 AJP1 A1=new AJP1();  

  }
}