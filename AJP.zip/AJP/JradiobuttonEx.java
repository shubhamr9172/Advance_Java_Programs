import javax.swing.*;
import java.awt.*;
class JradiobuttonEx extends JFrame
{
  JRadioButton b1,b2,b3;
  
  JradiobuttonEx()
   {
    b1=new JRadioButton("I");
    b2=new JRadioButton("II");
    b3=new JRadioButton("III");
    
    ButtonGroup bg=new ButtonGroup();
    bg.add(b1);
    bg.add(b2);
    bg.add(b3);
 
JLabel l1=new JLabel("Class");

    add(l1);
    add(b1);
    add(b2);
    add(b3);

setLayout(new FlowLayout());
setSize(400,400);
setVisible(true);
}
public static void main(String s[])
  {
    new JradiobuttonEx();
  }
}