import java.awt.*;
class ChoiceEx extends Frame
 {
   ChoiceEx()
   {
    Choice c=new Choice();
    c.add("Java");
    c.add("AdvanceJava");
    c.add("CoreJava");
    c.add("JavaScript");
   
    add(c);
    setSize(400,400);
    setVisible(true);
    setLayout(new FlowLayout());
   }
  public static void main(String s[])
    {
     new ChoiceEx();
   }
}
