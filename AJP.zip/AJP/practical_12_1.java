import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class practical_12_1 extends JFrame implements ActionListener
{
      JLabel l1,l2,l3,l4,l5;
      JTextField t1;
      JPasswordField t2;
      JButton b;
    

     practical_12_1()
      {
       l1=new JLabel("Username :");
       l2=new JLabel("Password :");
       l3=new JLabel("Login");
       l4=new JLabel("Enter Username and pass");
       l5=new JLabel("User authentication");
       t1=new JTextField();
       t2=new JPasswordField();
       b=new JButton("OK");

add(l5);
add(l4);
       add(l1);

       add(t1);
       add(l2);
       add(t2);
       add(b);
       add(l3);
        b.addActionListener(this);
       setSize(400,400);
       setLayout(new GridLayout(4,2));
       setVisible(true);
     }
    public void actionPerformed(ActionEvent ae)
    {
      String s2=t1.getText();
      char s3[]=t2.getPassword();
      String s4=String.valueOf(s3);
     if(s2.equals("shubham") && s4.equals("1234"))
        {
         l3.setText("Login successfull");
         }
   else{l3.setText("failed");}
    }
public static void main(String s[])
  {
    new practical_12_1();
   }
}