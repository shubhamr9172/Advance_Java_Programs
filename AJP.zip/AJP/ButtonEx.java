import java.awt.*;
import java.awt.event.*;
public class ButtonEx extends Frame implements ActionListener
{
  Button red,green,blue;
  public ButtonEx()
   {
   red=new Button("Red");
   green=new Button("Green");
   blue=new Button("Blue");
   
   red.addActionListener(this);
   green.addActionListener(this);
   blue.addActionListener(this);
  
   add(red);
   add(green);
   add(blue);

  setTitle("Button Example");
  setSize(300,300);
  setVisible(true);
  setLayout(new FlowLayout());
  
  }
public void actionPerformed(ActionEvent ae)
  {
   String str=ae.getActionCommand();
    if (str.equals("Red"))
      {
       setBackground(Color.red);
      }
   else if(str.equals("Green"))
      {
       setBackground(Color.green);
      }
    else if(str.equals("Blue"))
      {
      
       setBackground(Color.blue);
      }
 }

public static void main(String s[])
{
  new ButtonEx();
}
}

