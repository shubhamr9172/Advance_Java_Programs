import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class login extends JFrame
{
//JPanel p1;
JLabel l1,l2;
JTextField t1,t2;
JButton b1,b2;

   login()
   {
     //p1=new JPanel();
     l1=new JLabel("Username :");
     t1=new JTextField();
     l2=new JLabel("Password :");
     t2=new JTextField();
     b1=new JButton("Submit");
     b2=new JButton("Reset");
     t1.setBounds(10,20,30,40);
    /* l1.setForegro,und(Color.white);
     l2.setForeground(Color.white);
     b1.setBackground(Color.blue);
     b2.setBackground(Color.blue);

     b1.setBackground(Color.white);
     b2.setBackground(Color.white);*/


     l1.setBounds(10,120,50,100);
     //add(p1);
     add(l1);
     add(t1);
     add(l2);
     add(t2);
     add(b1);
     add(b2);
     setBackground(Color.pink);
     setVisible(true);
//setLayout(new FlowLayout());
     setSize(400,400);

   }



public static void main(String args[])
{
new login();
}
}
     