import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class practical_12_2 extends JFrame implements ActionListener
{
      JLabel l1,l2,l3,l4,l5;
      JTextField t1;
      JTextField t2;
      JButton b;
    

     practical_12_2()
      {
       l1=new JLabel("Enter first number :");
       l2=new JLabel("Enter Second number :");
       l3=new JLabel();
       l4=new JLabel("Enter Two numbers");
       l5=new JLabel("Addition program");
       t1=new JTextField();
       t2=new JTextField();
       b=new JButton("ADD");

add(l5);
add(l4);
       add(l1);

       add(t1);
       add(l2);
       add(t2);
       add(b);
       add(l3);
        b.addActionListener(this);
       setSize(400,400);
       setLayout(new GridLayout(4,2));
       setVisible(true);
     }
    public void actionPerformed(ActionEvent ae)
    {
      int s2=Integer.parseInt(t1.getText());
      int s3=Integer.parseInt(t2.getText());
      int ans=s2+s3;
      String s4=String.valueOf(ans);
      l3.setText("Addition :"+s4);
    }
public static void main(String s[])
  {
    new practical_12_2();
   }
}