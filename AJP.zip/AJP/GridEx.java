import java.awt.*;
public class GridEx extends Frame
{ 
    GridEx()
   { int n=1;
     setLayout(new GridLayout(5,5));

      for(int i=0;i<5;i++)
       {
        for(int j=0;j<5;j++)
         { 
           add (new Button(" "+n));
           n++;
         }
}
     setSize(400,400);
     setVisible(true);
    }






   public static void main (String s[])
    {
     new GridEx();
        }
    
     
}
