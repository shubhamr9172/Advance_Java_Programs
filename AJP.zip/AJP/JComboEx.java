import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JComboEx extends JFrame implements ItemListener
{


   JComboBox jc;
   JLabel j1,l1;
    JComboEx()
     {
      JPanel p = new JPanel(); 
      jc=new JComboBox();
      j1=new JLabel("select your Name");
       l1 = new JLabel("Shubham selected"); 

      jc.addItem("Shubham");
      jc.addItem("Ganesh");
      jc.addItem("Rohit");
      jc.addItem("Anand");
      
       p.add(j1);
      p.add(jc);
      p.add(l1);
       add(p);
      p.setLayout(new FlowLayout());

}

public void itemStateChanged(ItemEvent ae)
{ if (ae.getSource() == jc) { 
  
            l1.setText(jc.getSelectedItem() + " is selected"); 
        } 
}

public static void main(String s[])
{
   JComboEx cx=new JComboEx();
      cx.setSize(500,500);
      cx.setVisible(true);
}
}

