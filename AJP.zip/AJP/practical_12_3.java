import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class practical_12_3 extends JFrame implements ActionListener
{
      JLabel l1,l2,l3,l4,l5;
      JTextField t1;
      JPasswordField t2;
      JButton b;
    

     practical_12_3()
      {
       l1=new JLabel("Username :");
       l2=new JLabel("password :");
       l3=new JLabel();
       l4=new JLabel("Enter proper info");
       l5=new JLabel("User authentication");
       t1=new JTextField();
       t2=new JPasswordField();
       b=new JButton("ok");

add(l5);
add(l4);
       add(l1);

       add(t1);
       add(l2);
       add(t2);
       add(b);
       add(l3);
        b.addActionListener(this);
       setSize(400,400);
       setLayout(new GridLayout(4,2));
       setVisible(true);
     }
    public void actionPerformed(ActionEvent ae)
    {
      String s2=t1.getText();
      char s3[]=t2.getPassword();
     String s4=String.valueOf(s3);
      if(s2.equals("shubham"))
        {
         if(s4.length()>6)
            {
             l3.setText("Login successfull");
            }
         else{l3.setText("password must be strong");}
    }else{l3.setText("invalid username");}
  }
public static void main(String s[])
  {
    new practical_12_3();
   }
}