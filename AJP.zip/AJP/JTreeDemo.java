/*<applet code="JTreeDemo" height=200 width=300>
</applet>*/

import java.awt.*;    
import java.awt.event.*;    
import javax.swing.*; 
import java.util.* ;
import javax.swing.tree.* ;   		             

public class JTreeDemo extends JApplet   
{
  JTree  jt;     
  JTextField jtf;
   
  public void init()   
  {
    setVisible(true);
  setSize(400,400);
    Container c = getContentPane();
    c.setLayout(new BorderLayout());
  	                                      
    DefaultMutableTreeNode rootnode = new DefaultMutableTreeNode("India");
    DefaultMutableTreeNode anode = new DefaultMutableTreeNode("Maharashtra");
    rootnode.add(anode);     		      
    DefaultMutableTreeNode ogames = new DefaultMutableTreeNode("Gujarat");
    DefaultMutableTreeNode bnode = new DefaultMutableTreeNode("Mumbai");
    DefaultMutableTreeNode vnode = new DefaultMutableTreeNode("Pune");
    DefaultMutableTreeNode enode = new DefaultMutableTreeNode("Nashik");
    DefaultMutableTreeNode dnode = new DefaultMutableTreeNode("Nagpur");
    anode.add(bnode);  		   
    anode.add(vnode); 
    anode.add(enode);  		   
    anode.add(dnode);   
    rootnode.add(ogames); 		      

   jt = new JTree(rootnode); 		      
   int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
   int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
   JScrollPane jsp = new JScrollPane(jt , v , h);

   c.add(jsp, "Center");   		    
   jtf = new JTextField(20);
   c.add( jtf, "South");
  //add(c);

   jt.addMouseListener(new MouseAdapter()   
   {
       public void mouseClicked(MouseEvent e)   
       {
         display(e);
    }  } ) ;
  }
  public void display(MouseEvent e)   
  {
    TreePath tp = jt.getPathForLocation(e.getX(), e.getY());
    if( tp  !=  null)
    System.out.println(tp);      
//jtf.setText(tp.toString());
    else
      //jtf.setText("");
     System.out.println(" ");
  }
}