import java.awt.*;
import javax.swing.*;
public class JTableEx extends JFrame
{
   JTable j;
  
       JTableEx()
     {
       
      setTitle("JTable Example");
       String data[][]={ {"101","Shubham","25000"},{"102","Anand","24000"},{"103","alim","25000"}};
       String colName[]={"id","name","salary"};
       j=new JTable(data,colName);
      JPanel p=new JPanel();
       p.add(new JScrollPane(j));
       add(p);
       setSize(400,400);
       setVisible(true);
   }
public static void main (String s[])
  {
   new JTableEx();
  }
}