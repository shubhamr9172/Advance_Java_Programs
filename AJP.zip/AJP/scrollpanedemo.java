import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class scrollpanedemo extends JApplet
{
Container cp=getContentPane();
JPanel jp=new JPanel();
public void init()
{


jp.setLayout(new GridLayout(20,20));
for(int i=0;i<=10;i++)
{
for(int j=0;j<=10;j++)
 {
   jp.add(new Button("Button:"+j));
 }
}
int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;

JScrollPane js =new JScrollPane(jp,v,h);
cp.add(js,BorderLayout.CENTER);

}
}
/*<Applet code="scrollpanedemo" height=400 width=500>
</Applet>*/