import java.awt.*;
class AJP extends Frame
{
  AJP()
  {
  Label l1 =new Label("Country");
  Label l2 =new Label("State");
  List t1=new List();
  List t2=new List(3,true);
  
  t1.add("India");
  t1.add("U.S.A");
  t1.add("Pakistan");
  
  t2.add("Maharashtra");
  t2.add("Rajasthan");
  t2.add("Karnataka");
  t2.add("Andhra Pradesh");
  
  add(l1);
  add(t1);
  add(l2);
  add(t2);
  setSize(400,300);
  setVisible(true);
 setLayout(new GridLayout(2,3));
  
  
  }
public static void main(String s[])
  {
  AJP a1=new AJP();
  
  }  
  
  
  
  }