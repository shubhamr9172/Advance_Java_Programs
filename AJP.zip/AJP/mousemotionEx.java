import java.awt.*;
import java.awt.event.*;
 public class mousemotionEx extends Frame implements MouseMotionListener
{
    mousemotionEx()
    {
   addMouseMotionListener(this);
   setSize(400,500);
   setLayout(null);
   setVisible(true);
   }
public void mouseDragged(MouseEvent me)
 {
Graphics g=getGraphics();
g.setColor(Color.blue);
g.fillOval(me.getX(),me.getY(),20,20);
}
public void main(String s[])
 {
  new mousemotionEx();
}
}