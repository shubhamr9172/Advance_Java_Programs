import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WindowDemo
 {
   Frame f;
   WindowDemo()
   {
    f=new Frame("window Adapter");
    f.addWindowListener(new WindowAdapter()
     {
       public void WindowClosing(WindowEvent ae)
            { 
            f.dispose();
           }
      });
   f.setSize(400,400);
   f.setLayout(null);
    f.setVisible(true);
  }
   public static void main(String s[])
   {
    new WindowDemo();
   }
}