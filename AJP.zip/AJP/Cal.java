import java.awt.*;
import java.awt.event.*;
class Cal extends Frame implements ActionListener
{

  TextField t1,t2,t3;
  Button b1,b2,b3,b4,b5;
  
  Cal()
    {
      t1= new TextField();
      t2= new TextField();
      t3= new TextField(); 
      
      b1=new Button("add");
      b2=new Button("Sub");
      b3=new Button("Mul");
      b4=new Button("Div");
      b5=new Button("Clear");
     
     b1.addActionListener(this);
     b2.addActionListener(this);
     b3.addActionListener(this);
     b4.addActionListener(this);
     b5.addActionListener(this);
   
   add(t1);add(t2);add(t3);
   add(b1);add(b2);add(b3);add(b4);add(b5);


   setSize(500,500);
   setVisible(true);
  setLayout(new FlowLayout());
}

public void actionPerformed(ActionEvent ae)
 {
     if(ae.getSource()==b1)
      {
       int a=Integer.parseInt(t1.getText());
       int b=Integer.parseInt(t2.getText());
       int c=a+b;
      t3.setText( String.valueOf(c));
      }

    else if(ae.getSource()==b2)
      {
       int a=Integer.parseInt(t1.getText());
       int b=Integer.parseInt(t2.getText());
       int c=a-b;
       t3.setText(String.valueOf(c));
      }
    else if(ae.getSource()==b3)
      {
       int a=Integer.parseInt(t1.getText());
       int b=Integer.parseInt(t2.getText());
       int c=a*b;
       t3.setText(String.valueOf(c));
      }
    else if(ae.getSource()==b4)
      {
       int a=Integer.parseInt(t1.getText());
       int b=Integer.parseInt(t2.getText());
       int c=a/b;
       t3.setText(String.valueOf(c));
      }
    else if(ae.getSource()==b5)
      {
t1.setText(" ");
t2.setText(" ");
t3.setText(" ");

      }
}
public static void main(String s[])
{
  Cal c1=new Cal();
 }
}