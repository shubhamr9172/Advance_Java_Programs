import java.awt.*; 
import javax.swing.*; 
public class JFrameContentPane  extends JFrame 
{     
     Container con = getContentPane(); 
     JButton Btn = new JButton("Click it"); 
     public JFrameContentPane() 
       { 
           
          setSize(500,500); 
          setVisible(true); 
          con.setLayout(new FlowLayout()); 
          con.add(Btn); 
       } 
         public static void main(String[] args) 
          { 
            JFrameContentPane JFrameCP = new JFrameContentPane(); 
          }         
  } 