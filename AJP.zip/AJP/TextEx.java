import java.awt.*;
import java.awt.event.*;
class TextEx extends Frame implements TextListener
{
TextField t1,t2;
  TextEx()
   {
      t1=new TextField();
      t2=new TextField();
     t1.addTextListener(this);
     
    add(t1);
    add(t2);
    setLayout(new GridLayout(1,2));
    setSize(500,500);
    setVisible(true);
  }
public void textValueChanged(TextEvent e)
 {
   t2.setText(t1.getText());
 }
public static void main(String s[])
{
 new TextEx();
}
}
     