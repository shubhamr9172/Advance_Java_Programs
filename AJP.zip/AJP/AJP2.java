import java.awt.*;
public class AJP2 extends Frame
{
AJP2()
{
Label l1=new Label("Username:");
TextField f1=new TextField();
Label l2=new Label("Password");
TextField f2=new TextField();
TextArea t1=new TextArea("This is an exxample.");
add(l1);
add(f1);
add(l2);
add(f2);
add(t1);
f2.setEchoChar('*');
setSize(400,300);
setVisible(true);
setLayout(new GridLayout(3,3));
}
public static void main(String s[])
{
AJP2 a1=new AJP2();


}
}