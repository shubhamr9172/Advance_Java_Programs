import java.awt.*;
class practical3 extends Frame
{
  practical3()
   {
    Button b1=new Button("Button1");
    Button b2=new Button("Button2");
    Button b3=new Button("Button3");
    Button b4=new Button("Button4");
    Button b5=new Button("Button5");
    
    add(b1);add(b2);add(b3);add(b4);
    add(b5);
    setSize(400,400);
    setVisible(true);
    setLayout(new GridLayout(3,2,5,5));
     }
 public static void main(String s[])
     {
      practical3 p1=new practical3();
     }
}
  