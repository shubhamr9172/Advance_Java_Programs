import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class JbuttonExPane extends JFrame implements ActionListener
{   Container p=getContentPane();
    JRadioButton j1,j2,j3;
    JbuttonExPane()
     {
       j1=new JRadioButton("Red");
       j2=new JRadioButton("Blue");
       j3=new JRadioButton("Green");
 
      j1.addActionListener(this);
      j2.addActionListener(this);
      j3.addActionListener(this);

      ButtonGroup bg =new ButtonGroup();
   
     
      bg.add(j1);
      bg.add(j2);
      bg.add(j3);
      p.add(j1);
      p.add(j2);
      p.add(j3);
      
      setSize(500,500);
      setVisible(true);
      p.setLayout(new FlowLayout());
}

public void actionPerformed(ActionEvent ae)
{
 String str=ae.getActionCommand();
    if(str.equals("Red"))
      {
        p.setBackground(Color.red);
       }
     else if(str.equals("Blue"))
    {
     p.setBackground(Color.blue);
 }
     else if(str.equals("Green"))
    {
     p.setBackground(Color.green);
 }
}

public static void main(String s[])
{
   new JbuttonExPane();
}
}

