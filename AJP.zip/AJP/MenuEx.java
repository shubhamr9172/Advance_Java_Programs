import java.awt.*;
class MenuEx extends Frame
{
  MenuEx()
    {
      MenuBar m1=new MenuBar();

      Menu u1=new Menu("File");
      Menu u2=new Menu("Edit");
      Menu u3=new Menu("Format");
      Menu u4=new Menu("View");
      Menu u5=new Menu("Help");
      
      MenuItem i1=new MenuItem("New");
      MenuItem i2=new MenuItem("Open");
      MenuItem i3=new MenuItem("Save");
      MenuItem i4=new MenuItem("Save as");
      
      MenuItem i5=new MenuItem("Undo");
      MenuItem i6=new MenuItem("Cut");
      
      m1.add(u1);
      m1.add(u2);
      m1.add(u3);
      m1.add(u4);
      m1.add(u5);

      u1.add(i1);
      u1.add(i2);
      u1.add(i3);
      u1.add(i4);
      u2.add(i5);
      u2.add(i6);

     setMenuBar(m1);
     setSize(500,600);
     setVisible(true);
     setLayout(new FlowLayout());
    }
public static void main (String s[])
  {
    new MenuEx();
 }
}

      
