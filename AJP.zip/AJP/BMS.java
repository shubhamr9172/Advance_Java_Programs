import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


class HomePage implements ActionListener
{
	Frame f1,f2,f3,f4,f5,f6,f7,f8,f9;
	
	JPanel p1,p2,p3,p4,p5;
	JButton b1,b2,b7,b8,b4,b5,b6,b9;
	JLabel admin1,ul1,pl1,admin,userLabel, passLabel,l1;
	JTextField Ut1,Usrename1;
	JPasswordField ut2,Adpassword ;
	JDialog d1;
	JButton b10,b11,b12,b13;   
     Color c;
	 
	 //Variable for create new account field frame f3
	  JLabel nal1,nal2;
	  JButton nab1,nab2,nab4,nab3;
	  JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10,tf11,tf12,tf13,tf14,tf15,tf16,tf17,tf18,tf19,tf20,tf21,tf22,tf23,tf24;
	  JTextField tf25,tf26,tf27,tf28,tf29,tf30,tf31,tf32,tf33,tf34,tf35,tf36;
	 JCheckBox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8,cb9,cb10,cb11,cb12,cb13,cb14,cb15,cb16,cb17,cb18,cb19,cb20,cb21,cb22,cb23,cb24,cb25,cb26,cb27,cb28;
	 
	 
	// Frame f1 user login
	
 	Font fo1;
    JButton jb1,jb2;
 
//Variable for Check balance f4


JTextField ct1,ct2,ct3,ct4,ct5,ct6,ct7,ct8,ct9;
JButton bb1,bb2,bb3,bb4,bb5,bb6,bb7,bb8,bb9;


	
public void HomePage()
{
	
	f5 = new JFrame("Home page");
	fo1 = new Font("Aerial",Font.BOLD,18);
	c = new Color(119,146,162);
	
	f1 = new Frame("User login");  //user login
	f2 = new Frame("admin login");  //admin login

	
 p1 = new JPanel();     //Home
 p2 = new JPanel();     //rule

 /*ImageIcon i2 = new ImageIcon("rule.gif");
 JLabel rl1 = new JLabel(i2);
 p2.add(rl1);
 rl1.setBounds(0,0,1000,1000);
 p2.setLayout(null);
*/ 
 
 
 p3 = new JPanel();     //contact us
 p4 = new JPanel();     //information
 p5 = new JPanel();


p1.setBackground(c);
//Home panel started
//ImageIcon i1 = new ImageIcon("i1.gif");
ImageIcon i1 = new ImageIcon("rupesh12.jpg");       //login page image   
JLabel l1 = new JLabel(i1);                         //label for image
p1.setLayout(null);                                 //p1 for Panel in home tab
l1.setBounds(-100,0,1000,250);                      //l1 obj for panel
p1.add(l1);                                         //p1 is object panel 1

//admin login
 userLabel = new JLabel("Username:");               //Label for username
 Usrename1 = new JTextField();                      //textbox for username
 passLabel = new JLabel("Password:");               //label for password
 Adpassword = new JPasswordField();                   //textbox for password
 
 
 
 p1.add(userLabel);                                  //add username label in panel 1
userLabel.setBounds(280,380,90,30);                  //setbound for label username
p1.add(Usrename1);                                   //add textbox in panel 1
Usrename1.setBounds(390,380,180,30);                 //username1 is obj of textbox for username
p1.add(passLabel);                                   //add password label in panel 1
passLabel.setBounds(280,440,90,30);                  
p1.add(Adpassword);                                //adpassord is obj of jpasswordfield
Adpassword.setBounds(390,440,180,30);

 
 admin = new JLabel("ADMIN LOGIN");
p1.add(admin);
admin.setBounds(340,310,200,50);
admin.setFont(fo1);

b1 = new JButton("Login");
p1.add(b1);
b1.setBounds(310,510,80,30);


 b2 = new JButton("Reset");
p1.add(b2);
b2.setBounds(450,510,80,30);

/*ImageIcon i2 = new ImageIcon("rupesh12.jpeg");
JButton b3 = new JButton(i2);
p1.add(b3);
b3.setBounds(670,530,80,30);
*/


 b4 = new JButton("Choose color");
p1.add(b4);
b4.setBounds(50,260,90,30);
b4.addActionListener(this);
 b5 = new JButton("User Login");
p1.add(b5);
b5.setBounds(160,260,130,30);     // user login



 b6 = new JButton("Admin Login");
p1.add(b6);
b6.setBounds(310,260,130,30);
 
	 
 b9 = new JButton("create new User Account");
p1.add(b9);

b9.setBounds(450,260,180,30); 

b9.addActionListener(this);







  












JTabbedPane jp = new JTabbedPane();

jp.add("Home",p1);
jp.add("Services",p2);
jp.add("Contact us ",p3);
jp.add("Information",p4);
jp.add("About us",p5);

b5.addActionListener(this);
b6.addActionListener(this);
b2.addActionListener(this);
b1.addActionListener(this);

f5.add(jp);
f5.setSize(800,800);
f5.setVisible(true);

}



public void Userlogin()
{
	
	                                        //User Login Frame f1//

 Font fo20 = new Font("Times New Roman",Font.BOLD,26);

JLabel ul1 = new JLabel("Welcome in State Bank Of India");
f1.add(ul1);
ul1.setBounds(200,20,600,50);
ul1.setFont(fo20);
ul1.setForeground(Color.black);

/*ImageIcon ii1=new ImageIcon("rup1.jpg");
JLabel ul3 = new JLabel(ii1);
f1.add(ul3);
ul3.setBounds(10,310,800,400);
*/

f1.setBackground(new Color(81,212,75));	
	
b10 = new JButton("Check Balance");
b11 = new JButton("Deposite Funds");
b12 = new JButton("Withdraw Cash");
b13 = new JButton("Transfer Funds");

f1.add(b10);
f1.add(b11);
f1.add(b12);
f1.add(b13);


b11.addActionListener(this);
b12.addActionListener(this);
b13.addActionListener(this);


f1.setLayout(null);





b10.setBounds(80,370,300,60);
b11.setBounds(80,440,300,60);
b12.setBounds(80,510,300,60);
b13.setBounds(80,580,300,60);




ImageIcon ui1= new ImageIcon("wind.jpg");
JLabel ul2 = new JLabel(ui1); 
f1.add(ul2);
ul2.setBounds(10,60,800,300);



jb1= new JButton("Home");
jb2 = new JButton("Back");



f1.add(jb1);
f1.add(jb2);

jb1.setBounds(500,600,100,40);
jb2.setBounds(620,600,100,40);

jb1.addActionListener(this);
jb2.addActionListener(this);

b10.addActionListener(this);
f4 = new JFrame("Check Balance");
f4.setLayout(null);

}

public void checkBalance()
{
	
	
	
	
	
	ImageIcon ci1 = new ImageIcon("check.jpg");
	JLabel cl1 = new JLabel(ci1);
		cl1.setBounds(10,20,800,200);
	f4.add(cl1);
	
	 new Font("Arial",Font.BOLD,16);
	JLabel cl5 = new JLabel("Bank name: State Bank of India");
	f4.add(cl5);
	cl5.setBounds(120,230,350,40);
	cl5.setFont( new Font("Arial",Font.BOLD,22));
	
	JLabel cl6 = new JLabel("IFSC Code: SBIN0020363");
	f4.add(cl6);
	cl6.setBounds(600,230,150,40);
	
	JLabel cl7 = new JLabel("Date:");
	f4.add(cl7);
	cl7.setBounds(600,270,150,40);
	
	
	
	
	
	
	
	Font cf = new Font("Arial",Font.BOLD,19);
	JLabel cl2 = new JLabel("Account no:");
	f4.add(cl2);
	cl2.setBounds(35,300,130,30);
	cl2.setFont(cf);
 
     ct1 = new JTextField(12);
    f4.add(ct1);
ct1.setEditable(false);	
ct1.setText("Account no");
     
   ct1.setBounds(230,300,200,30);



    JLabel cl3 = new JLabel("Your name");
    f4.add(cl3);
	cl3.setBounds(35,360,130,30);
	cl3.setFont(new Font("Arial",Font.BOLD,19));
	


  ct2 = new JTextField();
  f4.add(ct2);
  ct2.setBounds(170,360,170,30);
	ct2.setEditable(false);	


ct3 = new JTextField();
  f4.add(ct3);
  ct3.setBounds(350,360,170,30);
 	ct3.setEditable(false);


ct4 = new JTextField();
  f4.add(ct4);
  ct4.setBounds(530,360,170,30); 
	ct4.setEditable(false);

Font cf1 = new Font("Arial",Font.BOLD,19);
JLabel cl4 = new JLabel("Your Account Balance:");
f4.add(cl4);
cl4.setBounds(35,430,220,30);
cl4.setFont(cf1);
cl4.setForeground(new Color(123,160,8));



ct5 = new JTextField("0000.00");
f4.add(ct5);
ct5.setBounds(270,430,220,30);
ct5.setEditable(false);













bb1 = new JButton("Home");
f4.add(bb1);
bb1.setBounds(500,600,90,30);

bb2 = new JButton("Back");
f4.add(bb2);
bb2.setBounds(600,600,90,30);

bb1.addActionListener(this);
bb2.addActionListener(this);







  


  
 
	
}


JTextField dt1,dt2,dt3,dt4,dt5,dt6;
JButton db1,db2,db3,db4;



public void depositFund()
{
	f6 = new JFrame("Deposit Fund");
	f6.setSize(800,800);
	f6.setLayout(null);

	
   JLabel dl1 =new JLabel(new ImageIcon("dep.jpg"));
   f6.add(dl1);
    dl1.setBounds(10,10,800,250);
  




	JLabel dl2 = new JLabel("Bank name: State Bank of India");
	f6.add(dl2);
	dl2.setBounds(120,270,350,40);
	dl2.setFont( new Font("Arial",Font.BOLD,22));
	
	
	
	JLabel dl3 = new JLabel("IFSC Code: SBIN0020363");
	f6.add(dl3);
	dl3.setBounds(600,270,150,40);
	
	JLabel dl4 = new JLabel("Date:");
	f6.add(dl4);
	dl4.setBounds(600,300,100,40);
	

 
JLabel d1 = new JLabel();
f6.add(d1);
d1.setBounds(660,300,150,40);

  Calendar calendar = Calendar.getInstance();  
   
d1.setText(""+calendar.getTime());
 
    

	
	
	
	
	 
	JLabel dl5 = new JLabel("Account no:");
	f6.add(dl5);
	dl5.setBounds(30,320,130,30);
	dl5.setFont(new Font("Arial",Font.BOLD,19));
 
 
 
     dt1 = new JTextField(12);
    f6.add(dt1);
dt1.setEditable(false);	
dt1.setText("Account no");
     
   dt1.setBounds(230,320,200,30);



    JLabel dl6 = new JLabel("Your name");
    f6.add(dl6);
	dl6.setBounds(30,380,150,30);
	dl6.setFont(new Font("Arial",Font.BOLD,19));
	


  dt2 = new JTextField();
  f6.add(dt2);
  dt2.setBounds(180,380,150,30);
	dt2.setEditable(false);	


dt3 = new JTextField();
  f6.add(dt3);
  dt3.setBounds(350,380,150,30);
 	dt3.setEditable(false);


dt4 = new JTextField();
  f6.add(dt4);
  dt4.setBounds(530,380,150,30); 
	dt4.setEditable(false);


JLabel dl7 = new JLabel("Your Current Account Balance:");
f6.add(dl7);
dl7.setBounds(35,450,300,30);
dl7.setFont(new Font("Arial",Font.BOLD,19));
dl7.setForeground(new Color(123,160,8));

dt6 = new JTextField();
f6.add(dt6);
dt6.setBounds(370,450,300,30);
	dt6.setEditable(false);

dt6.setText(ct5.getText());

	

JLabel dl8 = new JLabel("Enter Deposit Amount:");
f6.add(dl8);
dl8.setBounds(35,500,300,30);
dl8.setFont(new Font("Arial",Font.BOLD,19));
dl8.setForeground(new Color(123,160,8));




dt5 = new JTextField();
f6.add(dt5);
dt5.setBounds(300,500,300,30);




db1 = new JButton("Home");
f6.add(db1);
db1.setBounds(300,600,90,30);
db1.addActionListener(this);


db2 = new JButton("Back");
f6.add(db2);
db2.setBounds(400,600,90,30);
db2.addActionListener(this);

db3 = new JButton("Cancle");
f6.add(db3);
db3.setBounds(500,600,90,30);
db3.addActionListener(this);

db4 = new JButton("Submit");
f6.add(db4);
db4.setBounds(600,600,90,30);
db4.addActionListener(this);


db4.addActionListener(this);

}



JFrame F7;
JTextField wt1,wt2,wt3,wt4,wt5,wt6,wt7,wt8,wt9;
JButton wb1,wb2,wb3,wb4;

public void WithdrawCash()
{
	f7=new JFrame("Withdraw Cash");
	f7.setLayout(null);
	
	
	
	 JLabel wl1 = new JLabel(new ImageIcon("with.jpg"));
	 f7.add(wl1);
	 wl1.setBounds(10,10,800,250);
	 
	 

	JLabel wl2 = new JLabel("Bank name: State Bank of India");
	f7.add(wl2);
	wl2.setBounds(120,270,350,40);
	wl2.setFont( new Font("Arial",Font.BOLD,22));
	
	
	
	JLabel wl3 = new JLabel("IFSC Code: SBIN0020363");
	f7.add(wl3);
	wl3.setBounds(600,270,150,40);
	
	JLabel wl4 = new JLabel("Date:");
	f7.add(wl4);
	wl4.setBounds(600,300,150,40);
	
	
	
	JLabel dd1 = new JLabel();
f7.add(dd1);
dd1.setBounds(660,300,150,40);

  Calendar calendar = Calendar.getInstance();  
   
dd1.setText(""+calendar.getTime());
	
	
	 
	JLabel wl5 = new JLabel("Account no:");
	f7.add(wl5);
	wl5.setBounds(30,320,130,30);
	wl5.setFont(new Font("Arial",Font.BOLD,19));
 
 
 
     wt1 = new JTextField(12);
    f7.add(wt1);
wt1.setEditable(false);	
wt1.setText("Account no");
     
   wt1.setBounds(230,320,200,30);
   
   
  
   



    JLabel wl6 = new JLabel("Your name");
    f7.add(wl6);
	wl6.setBounds(30,380,150,30);
	wl6.setFont(new Font("Arial",Font.BOLD,19));
	


  wt2 = new JTextField();
  f7.add(wt2);
  wt2.setBounds(180,380,150,30);
	wt2.setEditable(false);	
     
	 

wt3 = new JTextField();
  f7.add(wt3);
  wt3.setBounds(350,380,150,30);
 	wt3.setEditable(false);


wt4 = new JTextField();
  f7.add(wt4);
  wt4.setBounds(530,380,150,30); 
	wt4.setEditable(false);


JLabel wl7 = new JLabel("Your Current Account Balance:");
f7.add(wl7);
wl7.setBounds(35,450,300,30);
wl7.setFont(new Font("Arial",Font.BOLD,19));
wl7.setForeground(new Color(123,160,8));

wt6 = new JTextField();
f7.add(wt6);
wt6.setBounds(370,450,300,30);
	wt6.setEditable(false);
	
	
	wt6.setText(dt6.getText());
	

JLabel wl8 = new JLabel("Enter Required Amount:");
f7.add(wl8);
wl8.setBounds(35,500,300,30);
wl8.setFont(new Font("Arial",Font.BOLD,19));
wl8.setForeground(new Color(123,160,8));




wt5 = new JTextField();
f7.add(wt5);
wt5.setBounds(300,500,300,30);




wb1 = new JButton("Home");
f7.add(wb1);
wb1.setBounds(300,600,90,30);
wb1.addActionListener(this);


wb2 = new JButton("Back");
f7.add(wb2);
wb2.setBounds(400,600,90,30);
wb2.addActionListener(this);

wb3 = new JButton("Cancle");
f7.add(wb3);
wb3.setBounds(500,600,90,30);
wb3.addActionListener(this);

wb4 = new JButton("Submit");
f7.add(wb4);
wb4.setBounds(600,600,90,30);
wb4.addActionListener(this);

wb1.addActionListener(this);
wb2.addActionListener(this);
wb3.addActionListener(this);
wb4.addActionListener(this);

	
	
	
	
	
	
	
}

JDialog wd1;
JButton wdb1;
public void DialogWith()
{
	wd1 = new JDialog(f7,"withdraw",true);
	
	JLabel dl1 =new JLabel("Insufficient Balance ");
	wd1.add(dl1);
	
	dl1.setFont(new Font("Arial",Font.BOLD,19));
	dl1.setBounds(50,50,200,40);
	wd1.setSize(350,200);
	wd1.setLocation(200,300);
	
	wdb1=new JButton("ok");
	
	wd1.add(wdb1);
	
	wdb1.setBounds(100,100,120,30);
	
	wdb1.addActionListener(this);
	
	
	wd1.setLayout(null);
}
	
	








	
	
	public void CreateAccount()
	{
	f3 = new Frame("new user account");  //new user account
     f3.setBackground(new Color(153,138,94));
	  
	 ImageIcon i3 = new ImageIcon("f1.gif");
	 nal1 = new JLabel(i3);
	 f3.add(nal1);
   nal1.setBounds(200,20,350,120);
   fo1 = new Font("Times New Roman",Font.BOLD,30);	
   nal1.setFont(fo1);
	nal1.setForeground(Color.blue);
	
	
	
	JLabel nal3 = new JLabel("IFSC Code: SBIN0020363"); 
	f3.add(nal3);
	nal3.setBounds(600,50,150,20);
	
	nal2 = new JLabel("Date :");
	f3.add(nal2);
	 nal2.setBounds(600,90,60,20);
	 
	JLabel dp1 = new JLabel();
f3.add(dp1);
dp1.setBounds(660,80,150,40);

  Calendar calendar = Calendar.getInstance();  
   
dp1.setText(""+calendar.getTime());
	
	
	
	
	 Font fo2 = new Font("Times New Roman",Font.BOLD,24);
	JLabel nal4 = new JLabel("ACCOUNT OPENING FORM");
	f3.add(nal4);
	nal4.setBounds(180,150,350,60);
	nal4.setForeground(Color.red);
	nal4.setFont(fo2);
	
	
	 //ImageIcon i4 = new ImageIcon("Home.jpeg");
	nab1 = new JButton("Home");
	f3.add(nab1);
	nab1.setBounds(40,40,70,40);
	
	nab1.addActionListener(this);
	//ImageIcon i3 = new ImageIcon();
	/*JLabel nal5 = new JLabel();
	f3.add(nal5);
	nal5.setBounds(20,20,150,150);
*/
   

JPanel nap1 = new JPanel();
nap1.setBounds(0,200,800,1000);
f3.add(nap1);
nap1.setLayout(null);

JLabel nal5 = new JLabel("Branch:");
f3.add(nal5);
nal5.setBounds(600,120,50,20);

JLabel nal6 = new JLabel("Account no");
nap1.add(nal6);
nal6.setBounds(90,10,70,20);

 tf1 = new JTextField(1);
 tf2 = new JTextField(1);
 tf3 = new JTextField(1);
 tf4 = new JTextField(1);
 tf5 = new JTextField(1);
 tf6 = new JTextField(1);
  tf7 = new JTextField(1);
  tf8 = new JTextField(1);
 tf9 = new JTextField(1);
  tf10 = new JTextField(1);
 tf11= new JTextField(1);
tf12= new JTextField(1);
tf13 = new JTextField(1);
 
nap1.add(tf1);
nap1.add(tf2);
nap1.add(tf3);
nap1.add(tf4);
nap1.add(tf5);
nap1.add(tf6);
nap1.add(tf7);
nap1.add(tf8);
nap1.add(tf9);
nap1.add(tf10);
nap1.add(tf11);
nap1.add(tf12);
nap1.add(tf13);

tf1.setBounds(10,30,20,20);
tf2.setBounds(30,30,20,20);
tf3.setBounds(50,30,20,20);
tf4.setBounds(70,30,20,20);
tf5.setBounds(90,30,20,20);
tf6.setBounds(110,30,20,20);
tf7.setBounds(130,30,20,20);
tf8.setBounds(150,30,20,20);
tf9.setBounds(170,30,20,20);
tf10.setBounds(190,30,20,20);
tf11.setBounds(210,30,20,20);
tf12.setBounds(230,30,20,20);
tf13.setBounds(250,30,20,20);


JLabel nal7 = new JLabel("Branch ALPHA");
nap1.add(nal7);
nal7.setBounds(360,10,100,20);

 tf14 = new JTextField(1);
 tf15 = new JTextField(1);
  tf16 = new JTextField(1);
tf17= new JTextField(1);
 tf18= new JTextField(1);
 tf19 = new JTextField(1);

nap1.add(tf14);
nap1.add(tf15);
nap1.add(tf16);
nap1.add(tf17);
nap1.add(tf18);
nap1.add(tf19);

tf14.setBounds(340,30,20,20);
tf15.setBounds(360,30,20,20);
tf16.setBounds(380,30,20,20);
tf17.setBounds(400,30,20,20);
tf18.setBounds(420,30,20,20);
tf19.setBounds(440,30,20,20);


JLabel nal8 = new JLabel("Scheme code");
nap1.add(nal8);
nal8.setBounds(580,10,100,20);
   
    tf20 = new JTextField(1);
  tf21 = new JTextField(1);
  tf22 = new JTextField(1);
  tf23= new JTextField(1);
 tf24= new JTextField(1);
 
   
   nap1.add(tf20);
nap1.add(tf21);
nap1.add(tf22);
nap1.add(tf23);
nap1.add(tf24);


tf20.setBounds(570,30,20,20);
tf21.setBounds(590,30,20,20);
tf22.setBounds(610,30,20,20);
tf23.setBounds(630,30,20,20);
tf24.setBounds(650,30,20,20);

JLabel nal9 = new JLabel("FULL NAME in CAPITAL Letters(in the order of first , middle and last name ,leaving a space between words)");
nap1.add(nal9);
nal9.setBounds(20,60,800,20);

tf25 = new JTextField("First name");
nap1.add(tf25);
tf25.setBounds(40,90,200,30);

tf26 = new JTextField("middle name");
nap1.add(tf26);
tf26.setBounds(260,90,200,30);

tf27= new JTextField("Last name");
nap1.add(tf27);
tf27.setBounds(480,90,200,30);

JLabel nal10 = new JLabel("Please choose frome the following");
nap1.add(nal10);
nal10.setBounds(20,120,400,30);

cb1 = new JCheckBox("Salaried");
 cb2 = new JCheckBox("Self Employed");
 cb3 = new JCheckBox("Professional");
 cb4 = new JCheckBox("Politician");
 cb5 = new JCheckBox("Housewife");
cb6 = new JCheckBox("Student");
 cb7 = new JCheckBox("Defence Staff");
 cb8 = new JCheckBox("Retired");
 cb9 = new JCheckBox("Stock Broker");
 cb10 = new JCheckBox("Agriculture");
 cb11 = new JCheckBox("Antique Dealer");
 cb12 = new JCheckBox("Arms Dealer");

 cb13 = new JCheckBox("Bussiness");
 cb14 = new JCheckBox("Others");

nap1.add(cb1);
nap1.add(cb2);
nap1.add(cb3);
nap1.add(cb4);
nap1.add(cb5);
nap1.add(cb6);
nap1.add(cb7);
nap1.add(cb8);
nap1.add(cb9);
nap1.add(cb10);
nap1.add(cb11);
nap1.add(cb12);
nap1.add(cb13);
nap1.add(cb14);


cb1.setBounds(20,140,80,30);
cb2.setBounds(100,140,120,30);
cb3.setBounds(220,140,100,30);
cb4.setBounds(320,140,100,30);
cb5.setBounds(430,140,110,30);
cb6.setBounds(560,140,70,30);
cb7.setBounds(660,140,150,30);

cb8.setBounds(20,170,80,20);
cb9.setBounds(100,170,120,20);
cb10.setBounds(220,170,100,20);
cb11.setBounds(320,170,110,20);
cb12.setBounds(430,170,110,20);
cb13.setBounds(560,170,100,20);
cb14.setBounds(660,170,150,20);


JLabel nal11 = new JLabel("Facility required ( please mark in appropriate box )");
  nap1.add(nal11);
  nal11.setBounds(20,200,400,20);
  
  cb15= new JCheckBox("Cheque Book");
  nap1.add(cb15);
  cb15.setBounds(20,220,130,20);
  
  cb16 = new JCheckBox("ATM card");
  nap1.add(cb16);
  cb16.setBounds(160,220,130,20);
  
  cb17 = new JCheckBox("Pass Book");
  nap1.add(cb17);
  cb17.setBounds(310,220,130,20);
   
   Font fo4 = new Font("Aerial",Font.BOLD,15);
   JLabel nal12 = new JLabel("City:");
   nap1.add(nal12);
   nal12.setBounds(20,250,50,30);
   nal12.setFont(fo4);
   
   tf28=new JTextField();
   nap1.add(tf28);
   tf28.setBounds(70,250,130,25);
   
     Font fo5 = new Font("Aerial",Font.BOLD,15);
   JLabel nal13 = new JLabel("District:");
   nap1.add(nal13);
   nal13.setBounds(210,250,60,30);
   nal13.setFont(fo5);
   
   
    tf29=new JTextField();
   nap1.add(tf29);
   tf29.setBounds(270,250,130,25);
   
   
   
    Font fo6 = new Font("Aerial",Font.BOLD,15);
   JLabel nal14 = new JLabel("State:");
   nap1.add(nal14);
   nal14.setBounds(410,250,50,25);
   nal14.setFont(fo6);
   
   
   
    tf30=new JTextField();
   nap1.add(tf30);
   tf30.setBounds(460,250,130,25);
   
   
    Font fo7 = new Font("Aerial",Font.BOLD,15);
   JLabel nal15 = new JLabel("Country:");
   nap1.add(nal15);
   nal15.setBounds(590,250,50,25);
   nal15.setFont(fo7);
   
      
    tf31=new JTextField();
   nap1.add(tf31);
   tf31.setBounds(640,250,130,25);
   
   
     Font fo8 = new Font("Aerial",Font.BOLD,15);
   JLabel nal16 = new JLabel("Pin Code:");
   nap1.add(nal16);
   nal16.setBounds(20,290,80,25);
   nal16.setFont(fo8);
   
   
    tf32=new JTextField();
   nap1.add(tf32);
   tf32.setBounds(100,290,100,25);
   
   
   
     Font fo9 = new Font("Aerial",Font.BOLD,15);
   JLabel nal17 = new JLabel("Mobile no:");
   nap1.add(nal17);
   nal17.setBounds(220,290,80,25);
   nal17.setFont(fo9);
   
   
   tf33=new JTextField();
   nap1.add(tf33);
   tf33.setBounds(320,290,150,25);
   
   
    Font fo10 = new Font("Aerial",Font.BOLD,15);
   JLabel nal18 = new JLabel("E-mail:");
   nap1.add(nal18);
   nal18.setBounds(490,290,80,25);
   nal18.setFont(fo10);
   
   
    tf34=new JTextField();
   nap1.add(tf34);
   tf34.setBounds(580,290,150,25);
   
   
   
   
      Font fo11 = new Font("Aerial",Font.BOLD,17);
   JLabel nal19 = new JLabel("Other Information:");
   nap1.add(nal19);
   nal19.setBounds(20,330,150,25);
   nal19.setFont(fo11);
   
   
   
    Font fo12 = new Font("Aerial",Font.BOLD,14);
   JLabel nal20 = new JLabel("Education:");
   nap1.add(nal20);
   nal20.setBounds(20,365,100,25);
   nal20.setFont(fo12);
   
   
   cb18 = new JCheckBox("Non Matric");
   nap1.add(cb18);
   cb18.setBounds(140,365,100,25);
   
   cb19 = new JCheckBox("SSC/HSC");
   nap1.add(cb19);
   cb19.setBounds(250,365,80,25);
   
   
   cb20 = new JCheckBox("Graduate");
   nap1.add(cb20);
   cb20.setBounds(340,365,100,25);
   
   
    cb21 = new JCheckBox("Post Graduate");
   nap1.add(cb21);
   cb21.setBounds(450,365,130,25);
   
   
    cb22 = new JCheckBox("Other");
   nap1.add(cb22);
   cb22.setBounds(580,365,100,25);
   
   
     Font fo13 = new Font("Aerial",Font.BOLD,14);
   JLabel nal21 = new JLabel("Monthly Income (Rs):");
   nap1.add(nal21);
   nal21.setBounds(20,410,150,25);
   nal21.setFont(fo13);
   
    cb23 = new JCheckBox("Upto 5000/-");
   nap1.add(cb23);
   cb23.setBounds(150,410,100,25);
   
       cb24 = new JCheckBox("5001-10000");
   nap1.add(cb24);
   cb24.setBounds(260,410,100,25);
   
   
   cb25 = new JCheckBox("10001-20000");
   nap1.add(cb25);
   cb25.setBounds(370,410,100,25);
   
   
   cb26 = new JCheckBox("20001-50000");
   nap1.add(cb26);
   cb26.setBounds(480,410,100,25);
   
   
    cb27 = new JCheckBox("50001-1 lac");
   nap1.add(cb27);
   cb27.setBounds(590,410,90,25);
   
   
    cb28 = new JCheckBox("Above 1 lac");
   nap1.add(cb28);
   cb28.setBounds(680,410,100,25);
   
   
   
     Font fo14 = new Font("Aerial",Font.BOLD,14);
   JLabel nal22= new JLabel("Password");
   nap1.add(nal22);
   nal22.setBounds(30,440,150,30);
   nal22.setFont(fo14);
   
   tf34 = new JTextField();
   nap1.add(tf34);
   tf34.setBounds(200,440,150,30);
   
   
      
   JLabel nal23= new JLabel("Conform Password");
   nap1.add(nal23);
   nal23.setBounds(30,480,150,30);
   nal23.setFont(new Font("Aerial",Font.BOLD,14));
   
    tf35 = new JTextField();
   nap1.add(tf35);
   tf35.setBounds(200,480,150,30);
   
   
   Font fo15 = new Font("Aerial",Font.BOLD,14);
  nab2 = new JButton("Submit");
nap1.add(nab2);
nab2.setBounds(400,470,120,30);  
   nab2.setFont(fo15);
   nab2.addActionListener(this);
   
   
   Font fo16 = new Font("Aerial",Font.BOLD,14);
   nab3 = new JButton("Cancle");
   nap1.add(nab3);
   nab3.setBounds(530,470,120,30);
   nab3.setFont(fo16);
   
   
   
   f3.setLayout(null);	 
   

	}	
	
	JDialog wd2;
JButton wdb2;
JLabel dl9 ;
public void wDialogWith()
{
	wd2 = new JDialog(f3,"account create successufully",true);
	wd2.setLayout(null);
	System.out.println(tf27.getText());
	
	dl9 =new JLabel();
	wd2.add(dl9);
	
	dl9.setFont(new Font("Arial",Font.BOLD,13));
	dl9.setBounds(50,50,500,40);
	
	wd2.setSize(540,200);
	wd2.setLocation(200,300);
	
	wdb2=new JButton("ok");
	
	wd2.add(wdb2);
	
	wdb2.setBounds(100,100,120,30);
	
	wdb2.addActionListener(this);
	
	
	wd1.setLayout(null);
	
}

JButton ab1;


public void AdminLogin()
{
	
	
	JLabel al2 = new JLabel(new ImageIcon("ad.jpeg"));
	f2.add(al2);
	al2.setBounds(5,20,800,400);
	
	
	
	 f2.setLayout(null);
	
	JLabel al1 = new JLabel("Welcome In State Bank OF India");
	f2.add(al1);
	al1.setBounds(230,30,300,20);
	al1.setFont(new Font("Arial",Font.BOLD,19));
	al1.setForeground(Color.blue);
	
	
	ab1 = new JButton("Staf Information");
	f2.add(ab1);
	ab1.setBounds(30,400,200,50);
	ab1.setFont(new Font("Arial",Font.BOLD,16));
	ab1.setForeground(new Color(201,161,88));
	
	
	ab1.addActionListener(this);
	
	
	
}

JFrame f10;
JTable table;

public void StaffInformation()
{
	f10 = new JFrame("Staff information");
	f10.setSize(800,800);
	f10.setLayout(new BorderLayout());
	
	
	 String column[] = {"Name","Designation","Branch/Office Name","Circle","Gross Salary","Status"};
String data[][] = {{"Rupesh Rajarwad","Chairman","CORPORATE CENTER" ,"SBI-CC-Mumbai","26550","Active"},{"Abhi Catap","Head messenger","L H O AMRAVATI","SBI-Amravati","71157.01","Active"},{"Mane Shrikant","Head Messenger","L H O AMRAVATI" , "SBI-Amravati","34726369","Active"},{"Mobin Shaikh","Asst. Vice President","L H O AMRAVATI","SBI-Amravati","54082.99","Active"},{"Siddheshwar Raut","Chief Off Security","COPERATIVE CENTER","SBI- CC-Mumbai","138000","Active"},{"Surinder Kumar Dhingra","ChiefCustServOffice","CORPORATE CENTR","SBI-CC-Mumbai","289285.71","active"},{"Ankit Katiyar","Manager","CORPORATE CENTR","SBI-CC-Mumbai","73333","Active"},{"Paulam Surendraprasad Mehta","Manager","Payment System","SBI-CC-Mumbai","194666","Active"}};
	
	table = new JTable(data,column);
	
table.setBounds(10,10,800,600);
JScrollPane sp = new JScrollPane(table);


f10.add(sp,BorderLayout.CENTER);

	
	

	
	
}

	
	public void AdoutUs()
	{
		JLabel abl1 = new JLabel("About Us");
		p5.add(abl1);
		
		
		
	}
	
	public void services()
	{
		
	
		ImageIcon si1 = new ImageIcon("s1.jpg");
		JLabel sl1= new JLabel(" ",si1,Label.LEFT);
		p2.add(sl1);
	
	  JLabel sl2 =new JLabel("Services                                                                                                                   ");
	  p2.add(sl2);
	  sl2.setFont(new Font("Arial",Font.BOLD,17));
      sl2.setForeground(Color.red);

	
		JLabel sl3 =new JLabel("1) Whatever your needs - an investment of your surplus funds or to create a fund for your childrens' education and marriage.");
		p2.add(sl3);
	  sl3.setFont(new Font("Arial",Font.BOLD,14));
	
	    JLabel sl4 = new JLabel("2)  You will find a product from SBI that suits your requirement, delivered at a branch close to you.                                                  ");
	   p2.add(sl4);
	  sl4.setFont(new Font("Arial",Font.BOLD,14));
	  
	  JLabel sl5 = new JLabel("3) Open an account with any of our branches, all of them are fully computerised, and realise the advantage of our vast network.");
	  p2.add(sl5);
	  	  sl5.setFont(new Font("Arial",Font.BOLD,14));
		  
		  
      JLabel sl6 = new JLabel("3) Place funds in Multi Option Deposit Scheme, a term deposit which is not fixed at all and comes with a unique break-up facility .");
p2.add(sl6);
sl6.setFont(new Font("Arial",Font.BOLD,14));	  

	JLabel sl7 =new JLabel("   which provides you full liquidity as well as benefits of higher rates of returns, through your savings bank account/Current account");
	  p2.add(sl7);
	  sl7.setFont(new Font("Arial",Font.BOLD,14));
	
	JLabel sl8 =new JLabel("4) . Enjoy 24 hour banking facility through our Internet Banking/ widest network of ATMs.                                                                          ");
	p2.add(sl8);
	sl8.setFont(new Font("Arial",Font.BOLD,14));
	
	
	}
  	
	public void ContactUs()
	{
		ImageIcon ci1 = new ImageIcon("c1.jpg");
		JLabel cl1 =new JLabel(ci1);
		p3.add(cl1);
		
		JLabel cl2 =new JLabel("State Bank of India has an extensive administrative structure to oversee the large network of branches in India and abroad.");
		
		p3.add(cl2);
		
		
	}
	JFrame f14;


JTextField pt1,pt2,pt3,pt4,pt5,pt6,pt7,pt8,pt9,pt10;		
public void Profile()
{
	f14=new JFrame("My Profile");
	f14.setSize(800,800);
	f14.setLayout(null);
	
	JLabel pl2 = new JLabel("My Profile");
	f14.add(pl2);
	pl2.setBounds(300,20,300,70);
	pl2.setFont(new Font("Times New Roman",Font.BOLD,23));
	
	JLabel pl1 =new JLabel(new ImageIcon("p.png"));
	f14.add(pl1);
    pl1.setBounds(600,20,150,150);	
	
	JLabel pl3 = new JLabel("My Name");
	f14.add(pl3);
	pl3.setBounds(30,100,100,30);
	pl3.setFont(new Font("Times New Roman",Font.BOLD,16));
	


	pt1 = new JTextField();
	f14.add(pt1);
	pt1.setBounds(130,100,130,30);
	
	
	pt2 = new JTextField();
	f14.add(pt2);
	pt2.setBounds(270,100,130,30);
	
	pt3 = new JTextField();
	f14.add(pt3);
	pt3.setBounds(410,100,130,30);
	
}	


	



public void actionPerformed(ActionEvent e)
{
	if(e.getSource()==b4)
	{
Color initialcolor =Color.GREEN;
Color color = JColorChooser.showDialog(f5,"select a color",initialcolor);
p1.setBackground(color);
}

	
else if (e.getSource()==b5)
{
	admin.setFont(fo1);
admin.setText("User Login");
 


	
}


else if(e.getSource()==b6)
{
	admin.setFont(fo1);
	admin.setText("Admin Login");

}


else if(e.getSource()==b1)
{
if(admin.getText().equals("User Login"))
{
	
	
	
	/*if(Usrename1.getText().equals(tf27.getText()) && Adpassword.getText().equals(""+tf34.getText()))
	{
		
		f1.setVisible(true);
		f1.setSize(800,800);
		f5.setVisible(false);
	}
	else
	{
	l1 = new JLabel("Login failed Plz try Again !!!! ");
	p1.add(l1);
	l1.setBounds(330,480,170,30);
	l1.setForeground(Color.red);
	}
	*/
	f1.setVisible(true);
		f1.setSize(800,800);
		f5.setVisible(false);
}


	
	
	
		if(admin.getText().equals("Admin Login"))
	{
	if(Usrename1.getText().equals("admin") && Adpassword.getText().equals("456"))
	{
	
		f2.setVisible(true);
		f2.setSize(800,800);
		
	}
	
	else
	{
	l1 = new JLabel("Login failed Plz try Again !!!! ");
	p1.add(l1);
	l1.setBounds(330,480,170,30);
	l1.setForeground(Color.red);
	}
	
	}
}


             //Reset button

else if(e.getSource()==b2)
{
	Usrename1.setText(null);
	Adpassword.setText(null);
	l1.setText(null);
}
else if(e.getSource()==b10)
{
	f4.setSize(800,800);
	f4.setVisible(true);
	
}
else if(e.getSource()==nab1)
{
	f5.setVisible(true);
	f3.setVisible(false);
}
else if(e.getSource()==jb1)
{
f5.setVisible(true);
f1.setVisible(false);

}

else if(e.getSource()==jb2)
{
f1.setVisible(false);
f5.setVisible(true);


}
else if(e.getSource()==bb1)
{
	f5.setVisible(true);
	f4.setVisible(false);
	
}
else if(e.getSource()==bb2)
{
	f1.setVisible(true);
	f4.setVisible(false);
	
}
else if(e.getSource()==b11)
{
	f6.setVisible(true);
	f1.setVisible(false);
}

else if(e.getSource()==db1)
{
	f5.setVisible(true);
	f6.setVisible(false);
}
else if(e.getSource()==db2)
{
	f1.setVisible(true);
	f6.setVisible(false);
	
}

else if(e.getSource()==nab2)
{
	
	
	
	
	dt2.setText(tf25.getText());
    dt3.setText(tf26.getText());
    dt4.setText(tf27.getText());
	ct2.setText(tf25.getText());
    ct3.setText(tf26.getText());
    ct4.setText(tf27.getText());
	
	
	
	
	
    wt2.setText(tf25.getText());
	wt3.setText(tf26.getText());
	wt4.setText(tf27.getText());
	
	if(tf34.getText().equals(tf35.getText()))
	{
	
	dl9.setText("Username= "+tf27.getText() +" password= "+tf34.getText());
	
	wd2.setVisible(true);
	}
	
	else
	{
		dl9.setText("password not match");
		wd2.setVisible(true);
	}
	
	
	
}
else if(e.getSource()==db4)
{
	float a = Float.parseFloat(dt5.getText());
	float b = Float.parseFloat(dt6.getText());
	
	System.out.println(""+a +""+b);
	float c =a+b;
	
	dt6.setText(" "+c);
	
	dt5.setText(null);
	
	ct5.setText(""+c);
	
	wt6.setText(""+c);
	
	
	
}
else if(e.getSource()==b12)
{
	f7.setVisible(true);
	f7.setSize(800,800);
	
}

else if(e.getSource()==wb1)
{
	f5.setVisible(true);
	f7.setVisible(false);
	
}

else if(e.getSource()==wb2)
{
	
	f1.setVisible(true);
	f7.setVisible(false);
}

else if(e.getSource()==wb3)
{
wt5.setText(null);	
	
}
else if(e.getSource()==wb4)
{
	
	
	
	
	float a = Float.parseFloat(wt6.getText());
	float b = Float.parseFloat(wt5.getText());
	if(a>b)
	{
	
	
	
	System.out.println(""+a +""+b);
	float c =a-b;
	
	wt6.setText(" "+c);
	
	wt5.setText(null);
	
	ct5.setText(""+c);
	dt6.setText(""+c);
	
	}
	else{
		
		wd1.setVisible(true);
		wt5.setText(null);
		
		
	}


}
else if(e.getSource()==wdb1)
{
	wd1.setVisible(false);
	wt5.setText(null);
}

else if(e.getSource()==ab1)
{
	
	f10.setVisible(true);
	f2.setVisible(false);
}
else if(e.getSource()==b13)
{
	
	f14.setVisible(true);
	f1.setVisible(false);
}


      // open frame for create account
	  
else if(e.getSource()==b9)
{


	f3.setVisible(true);
	f3.setSize(800,800);
    f5.setVisible(false);
}


 
														  
}

}





public class BMS
{
public static void main(String args[])
{
HomePage r = new HomePage();
r.HomePage();
r.Userlogin();
r.CreateAccount();
r.checkBalance();
r.depositFund();
r.WithdrawCash();
r.DialogWith();
r.AdoutUs();
r.services();
r.ContactUs();
r.wDialogWith();
r.AdminLogin();
r.StaffInformation();
r.Profile();
}

}