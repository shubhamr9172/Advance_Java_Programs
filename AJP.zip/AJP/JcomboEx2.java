import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class JcomboEx2 extends Frame implements ItemListener
{
JLabel l1,l2;
JComboBox c1;

 JcomboEx2()
  {
    String s1[]={"Latur", "Mumbai","Karnataka"};
    c1=new JComboBox(s1);
    l1=new JLabel("Select city");
    l2=new JLabel("Latur is Selected");

    c1.addItemListener(this);
    
    JPanel p=new JPanel();
    p.add(l1);
    p.add(c1);
    p.add(l2);
    add(p);
    setSize(500,400);
    setVisible(true);
}
public void itemStateChanged(ItemEvent e)
{
   if(e.getSource()==c1)
{
  l2.setText(c1.getSelectedItem()+"Selected");
}
}
public static void main(String s[])
{
  new JcomboEx2();
}
}
 