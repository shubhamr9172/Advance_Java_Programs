import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/*<applet code="MouseDemo3" width=300 height=200></applet>*/
public class MouseDemo3 extends Applet implements MouseMotionListener
{
Label l;
public void init()
{
 setLayout(null);
  l=new Label("Hello Mouse");
  l.setBounds(50,150,200,100);
 add(l);
 addMouseMotionListener(this);
}
public void mouseMoved(MouseEvent e)
{
setBackground(Color.red);

}
public void mouseDragged(MouseEvent e)
{
 setBackground(Color.black);
}

}