import java.awt.*;
import java.awt.event.*;
public class CardEx extends Frame implements ActionListener
{
    CardLayout card=new CardLayout(20,20);
    CardEx()
    {
    setLayout(card);
     Button b1 =new Button("SR");
     Button b2 =new Button("YK");
     Button b3 =new Button("RG");
      
     add(b1,"card1");
     add(b2,"card2");
     add(b3,"card3");
 
     b1.addActionListener(this);
      b2.addActionListener(this);
      b3.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
     {
      card.next(this);
     }

public static void main(String s[])
{
CardEx c=new CardEx();
c.setSize(400,400);
c.setVisible(true);
c.setResizable(false);
}
}
