import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class JcomboEx20 extends JFrame implements ActionListener
{
    JTextField t1,t2;
    JComboBox j;
    JButton b1,b2;
    JLabel l1=new JLabel("ADD & Remove Elements");
   JcomboEx20()
    {
     String s[]={"AJP","CSS","EDE","EST","OS","CGI","Python"};
     j=new JComboBox(s);
   add(j);
   j.addItem("Anand");
    t1=new JTextField();
    b1=new JButton("Add");
    t2=new JTextField();
    b2=new JButton("Delete");
    add(l1);
   add(t1);
   add(b1);
   add(t2);
   add(b2);
    b1.addActionListener(this);
     b2.addActionListener(this);
   setLayout(new GridLayout(4,2));
   setSize(400,500);
   setVisible(true);
   }
   public void actionPerformed(ActionEvent ae)
   { 
     String s1=t1.getText();
      int s2=Integer.parseInt(t2.getText());
     if(ae.getSource()==b1)
     {
j.addItem(s1);
  }
else if(ae.getSource()==b2)
 {
  j.removeItemAt(s2);
 }
      
  }
   
public static void main(String s[])
{
new JcomboEx20();
} 
}