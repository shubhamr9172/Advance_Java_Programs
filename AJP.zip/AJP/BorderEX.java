import java.awt.*;
class BorderEX
{
  BorderEX()
   {
    BorderLayout Bl=new BorderLayout();
    Frame f=new Frame("BorderLayout");

    Button b1 =new Button("North");
    Button b2 =new Button("East");
    Button b3 =new Button("West");
    Button b4 =new Button("South");
    Button b5 =new Button("Center");
    
    f.add(b1,BorderLayout.NORTH);
    f.add(b2,BorderLayout.EAST);
    f.add(b3,BorderLayout.WEST);
    f.add(b4,BorderLayout.SOUTH);
    f.add(b5,BorderLayout.CENTER);

    f.setSize(400,400);
   
    f.setVisible(true);
 f.setLayout(Bl);
   }
public static void main(String s[])
   {
    new BorderEX();
  }
}
   
    