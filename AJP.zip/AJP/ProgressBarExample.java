import javax.swing.*; 
import java.awt.event.*;
import java.awt.*;   
public class ProgressBarExample extends JFrame implements ActionListener{
JButton b;    
JProgressBar jb;    
int i=0,num=0;     
ProgressBarExample()
{    
jb=new JProgressBar(0,2000);    
jb.setBounds(40,40,160,30);         
jb.setValue(0);    
jb.setStringPainted(true); 
b=new JButton("ok");   
add(jb);    

add(b);

b.addActionListener(this); 
setSize(250,150);    
setLayout(new FlowLayout());   
}    
public void iterate()
{    
while(i<=2000)
{    
  jb.setValue(i);    
  i=i+20;    
  try{Thread.sleep(150);}catch(Exception e){}    
}    
}    
public void actionPerformed(ActionEvent e)
{
iterate();
 }
public static void main(String[] args) {    
    ProgressBarExample m=new ProgressBarExample();    
    m.setVisible(true);    
      
}    
}    